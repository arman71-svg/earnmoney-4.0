const firebaseConfig = {
  "apiKey": "AIzaSyDGRfIpM007gOR3OQi112N9PACIj6ubYyo",
  "authDomain": "earn-money-c536d.firebaseapp.com",
  "databaseURL": "https://earn-money-c536d-default-rtdb.asia-southeast1.firebasedatabase.app",
  "projectId": "earn-money-c536d",
  "storageBucket": "earn-money-c536d.appspot.com",
  "messagingSenderId": "800372550772",
  "appId": "1:800372550772:web:placeholder123"
};
